import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";
import { spotifyApi, authenticate } from "./spotify.js";
import "dotenv/config"
import { createPlaylist } from "./tools/createPlaylist.js"
import { searchSongs } from "./tools/searchSongs.js"


const server = new McpServer({
  name: "spotify-mcp",
  version: "1.0.0"
});

server.tool(
  "search_songs",
  "Search songs on Spotify",
  {
    query: z.string()
  },
  async ({ query }) => {

    const result = await spotifyApi.searchTracks(query);

    return {
      content: result.body.tracks.items.slice(0,5).map(track => ({
        type: "text",
        text: `${track.name} - ${track.artists.map(a => a.name).join(", ")}`
      }))
    };

  }
);


server.tool(
  "create_playlist",
  "Create a Spotify playlist",
  {
    name: z.string()
  },
  async ({ name }) => {

    const playlist = await createPlaylist(name)

    return {
      content: [
        {
          type: "text",
          text: `Playlist creada: ${playlist.name}`
        }
      ]
    }

  }
)










async function start() {

  await authenticate();

  const transport = new StdioServerTransport();

  await server.connect(transport);

}

start();