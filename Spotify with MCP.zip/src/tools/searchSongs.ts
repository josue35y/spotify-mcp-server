import { z } from "zod";
import { spotifyApi } from "../spotify.js";

export const searchSongsTool = {
  name: "search_songs",

  description: "Search songs on Spotify",

  schema: z.object({
    query: z.string()
  }),

  handler: async ({ query }: { query: string }) => {

    const result = await spotifyApi.searchTracks(query);

    return result.body.tracks?.items.map(track => ({
      name: track.name,
      artist: track.artists.map(a => a.name).join(", "),
      url: track.external_urls.spotify
    }));
  }
};